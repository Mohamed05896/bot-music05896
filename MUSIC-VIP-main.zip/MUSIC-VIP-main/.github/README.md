![Super-Music](https://telegra.ph/file/ba5e50feaff3c2bbde984.jpg)
# 𝗠𝗨𝗦𝗜𝗖 𝗦𝗣𝗜𝗗𝗘𝗥

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=WELCOME+TO+MUSIC-SPIDER+AN+ADVANCE+BOT)](https://github.com/FM8Y/Super-Music)

<p align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</p>

</h3>
<p align="center">
<a href="https://telegram.me/EE_47"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
<p align="center">
<a href="https://telegram.me/EE_20"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

تم تطوير و تعريب الملف بواسطة [OSAMA](https://t.me/WWWL5)

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"> <img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">




─「 [SOURCE SPIDER](https://t.me/EE_20) 」─ 


  الــمــلــف بــحــقــوق ســورس [ســبــايــدر](https://t.me/EE_20)

غـيـر مـسـمـوح بـتـغـيـيـر حـقـوق [الـمـلـف](https://t.me/EE_20)


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"> <img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

